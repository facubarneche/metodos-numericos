# TP METODOS NUMERICOS

El proyecto contiene 2 ejecutables, el primero (entrega.py) es el trabajo practico y el segundo (test.py) contiene diversas pruebas respecto a los metodos de biseccion y triseccion.

# Integrantes

* Andres Hernandez
* Facundo Barneche

# Como acceder al proyecto desde la nube

El proyecto se encuentra en https://github.com/facubarneche/metodos-numericos en la carpeta "Entrega".
